# -*- coding: utf-8 -*-
"""
Enviar plantilla de Outlook (.oft) con datos del REGISTRO DE SOLICITUDES.

Para una solicitud de inhibición, elige el tipo, completa los datos y el motivo
y abre el correo en Outlook directamente.

Flujo de las plantillas que consultan el registro:
 1. Pide: plantilla, entidad, DNI y una o varias cuentas (cada cuenta con su DK).
 2. Abre el Excel, escribe DNI y CUENTA en la tabla de la hoja de la entidad
    (IBK / BBVA / OTROS), ACTUALIZA DATOS (Power Query / base de datos) y recalcula.
 3. Lee NOMBRE, F_ADQ y DK que el Excel trae por fórmula (VLOOKUP a CONSOLIDADO).
 4. Abre la plantilla .oft, rellena asunto y cuerpo, y deja el correo abierto
    para que adjuntes evidencias y envíes (NO lo envía solo).

Requisitos (Windows): Outlook y Excel de escritorio, Python 3 y  pip install pywin32
"""
import json
import os
import re
import sys
import datetime as dt
from html import unescape
import tkinter as tk
from tkinter import ttk, messagebox, filedialog

import pythoncom
import win32com.client

# ----------------------------------------------------------------------------
# CONFIGURACIÓN (lo único que normalmente tendrás que tocar)
# ----------------------------------------------------------------------------
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
CONFIG_FILE = os.path.join(BASE_DIR, "config.json")

# Carpeta donde están los .oft (por defecto, la misma del script)
CARPETA_PLANTILLAS = BASE_DIR

# Tu nombre tal como aparece en la columna SOLICITUD del registro (déjalo "" si no quieres llenarlo)
ANALISTA = ""

# Hoja -> nombre de la tabla de Excel
TABLAS = {
    "IBK": ("IBK", "IBK_SOLICITUDES"),
    "BBVA": ("BBVA", "BBVA_SOLICITUDES"),
    "OTROS": ("OTROS", "OTROS_SOLICITUDES"),
}
NOMBRE_ENTIDAD = {"IBK": "INTERBANK", "BBVA": "BBVA", "OTROS": "ENTIDAD"}

# Cada plantilla:
#   archivo       : nombre del .oft
#   tipo          : valor que se escribe en "TIPO DE CONSULTA" del registro
#   registrar     : True  -> la fila queda guardada en el registro
#                   False -> solo se usa para consultar y la fila se borra al terminar
#   solo_interbank: avisa si eliges otra entidad (los destinatarios son de Interbank)
PLANTILLAS = {
    "Validación acuerdo de pago": dict(
        archivo="Plantilla_de_Validacion_acuerdo_de_pago.oft",
        tipo="Acuerdo con entidad", registrar=True, solo_interbank=True, kind="tabla"),
    "Validación cancelación de deuda": dict(
        archivo="Plantilla_de_Validacion_cancelacion_de_deuda.oft",
        tipo="Canceló con entidad original", registrar=True, solo_interbank=True, kind="tabla"),
    "Reporte de carga Sentinel": dict(
        archivo="Reporte_de_Carga_Sentinel.oft",
        tipo="Actualización de centrales", registrar=True, solo_interbank=False, kind="sentinel"),
    "Segunda carta de no adeudo": dict(
        archivo="SEGUNDA_CARTA_DE_NA.oft",
        tipo="Canceló con entidad original", registrar=False, solo_interbank=False, kind="carta"),
    "Solicitud de inhibición": dict(kind="inhibicion"),
}

TIPOS_INHIBICION = {
    "Solo DNI": ("Inhibicion dni.oft", ("DNI", "MOTIVO")),
    "Teléfono asociado a DNI": ("Inhibicion numero.oft", ("NÚMERO", "MOTIVO")),
    "Correo": ("Inhibicion correo.oft", ("DNI", "CORREO", "MOTIVO")),
}

# Formato del asunto. Variables: {entidad} {dni} {cuenta} {nombre} {fecha}
ASUNTOS = {
    "tabla":    "{entidad} - Expértis / Consulta Cliente DNI {dni} TITULAR",
    "sentinel": "CARGA_REPORTE SENTINEL_{dni}_{cuenta}{fecha}",
    "carta":    "Segunda carta de no adeudo_{dni}_{nombre}",
}


# ----------------------------------------------------------------------------
# Config persistente (ruta del Excel)
# ----------------------------------------------------------------------------
def cargar_config():
    if os.path.exists(CONFIG_FILE):
        with open(CONFIG_FILE, encoding="utf-8") as f:
            return json.load(f)
    return {}


def guardar_config(cfg):
    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)


def obtener_ruta_excel(cfg):
    ruta = cfg.get("ruta_excel", "")
    if not ruta or not os.path.exists(ruta):
        ruta = filedialog.askopenfilename(
            title="Selecciona el Excel REGISTRO DE SOLICITUDES",
            filetypes=[("Excel", "*.xlsx *.xlsm")])
        if not ruta:
            return None
        cfg["ruta_excel"] = ruta
        guardar_config(cfg)
    return ruta


# ----------------------------------------------------------------------------
# Excel
# ----------------------------------------------------------------------------
class ErrorDatos(Exception):
    pass


def _texto(v):
    if v is None:
        return ""
    if isinstance(v, float) and v.is_integer():
        v = int(v)
    return str(v).strip()


def abrir_excel(ruta):
    """Reutiliza el libro si ya está abierto; si no, lo abre en segundo plano."""
    try:
        app = win32com.client.GetActiveObject("Excel.Application")
        for wb in app.Workbooks:
            if os.path.normcase(wb.FullName) == os.path.normcase(ruta):
                return app, wb, False, False  # app, wb, cerrar_wb, cerrar_app
    except Exception:
        pass
    app = win32com.client.DispatchEx("Excel.Application")
    app.Visible = False
    app.DisplayAlerts = False
    wb = app.Workbooks.Open(ruta)
    return app, wb, True, True


def actualizar_datos(app, wb):
    """Equivale a Datos > Actualizar todo, esperando a que termine."""
    for con in wb.Connections:
        try:
            con.OLEDBConnection.BackgroundQuery = False
        except Exception:
            pass
    wb.RefreshAll()
    try:
        app.CalculateUntilAsyncQueriesDone()
    except Exception:
        pass
    app.CalculateFull()


def buscar_fila(tabla, dni, cuenta):
    col_doc = tabla.ListColumns("DOCUMENTO").Range
    col_cta = tabla.ListColumns("CUENTA").Range
    for i in range(2, col_doc.Rows.Count + 1):  # fila 1 = encabezado
        if _texto(col_doc.Cells(i, 1).Value) == dni and _texto(col_cta.Cells(i, 1).Value) == cuenta:
            return i - 1  # índice de ListRow (1-based)
    return None


def _valido(v):
    return not (v is None or isinstance(v, int) or _texto(v) in ("", "#N/A")
                or _texto(v).startswith("Error"))


def consultar_excel(ruta, hoja, nombre_tabla, dni, cuentas, tipo, registrar, entidad_otros):
    """Procesa 1 o varias cuentas del mismo DNI con una sola actualizacion de datos.
    Devuelve una lista de dicts: cuenta, nombre, f_adq, dk (cada cuenta con su DK)."""
    pythoncom.CoInitialize()
    app, wb, cerrar_wb, cerrar_app = abrir_excel(ruta)
    tabla = wb.Worksheets(hoja).ListObjects(nombre_tabla)
    indices = {}        # cuenta -> indice de fila en la tabla
    nuevas = []         # indices de filas agregadas en esta corrida
    try:
        for cuenta in cuentas:
            idx = buscar_fila(tabla, dni, cuenta)
            if idx is None:
                lr = tabla.ListRows.Add()
                idx = lr.Index
                nuevas.append(idx)
                fila = lr.Range

                def poner(col, valor, texto=False):
                    celda = fila.Cells(1, tabla.ListColumns(col).Index)
                    if texto:
                        celda.NumberFormat = "@"   # conserva ceros a la izquierda
                    celda.Value = valor

                poner("DOCUMENTO", dni, texto=True)
                poner("CUENTA", cuenta, texto=True)
                poner("TIPO DE CONSULTA", tipo)
                poner("FECHA DE SOLICITUD",
                      dt.datetime.now().replace(hour=0, minute=0, second=0, microsecond=0))
                if ANALISTA:
                    poner("SOLICITUD", ANALISTA)
                if hoja == "OTROS" and entidad_otros:
                    poner("ENTIDAD", entidad_otros)
            indices[cuenta] = idx

        actualizar_datos(app, wb)   # una sola vez para todas las cuentas

        datos, faltan = [], []
        for cuenta in cuentas:
            fila = tabla.ListRows(indices[cuenta]).Range

            def leer(col):
                return fila.Cells(1, tabla.ListColumns(col).Index).Value

            nombre = leer("NOMBRE")
            if not _valido(nombre):
                faltan.append(cuenta)
                continue
            datos.append(dict(cuenta=cuenta, nombre=_texto(nombre),
                              f_adq=leer("F_ADQ"), dk=leer("DK")))
        if faltan:
            raise ErrorDatos(
                "No se encontro en CONSOLIDADO (despues de actualizar los datos) la(s) cuenta(s): %s\n"
                "Revisa que esten bien escritas (con sus ceros) y que la base de datos este accesible.\n"
                "No se agrego nada al registro." % ", ".join(faltan))

        if nuevas and not registrar:        # solo consulta: no dejar filas
            for i in sorted(nuevas, reverse=True):
                tabla.ListRows(i).Delete()
            nuevas = []
        wb.Save()
        return datos
    except Exception:
        if nuevas:  # no dejar filas basura en el registro si algo fallo
            try:
                for i in sorted(nuevas, reverse=True):
                    tabla.ListRows(i).Delete()
                wb.Save()
            except Exception:
                pass
        raise
    finally:
        try:
            if cerrar_wb:
                wb.Close(SaveChanges=False)
            if cerrar_app:
                app.Quit()
        except Exception:
            pass


# ----------------------------------------------------------------------------
# Formato de valores
# ----------------------------------------------------------------------------
def fmt_fecha(v):
    try:
        return v.strftime("%d/%m/%Y")
    except AttributeError:
        return _texto(v)


def fmt_dk(v):
    try:
        return "S/. {:,.2f}".format(float(v))
    except (TypeError, ValueError):
        return _texto(v)


def esc(s):
    return (s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"))


# ----------------------------------------------------------------------------
# Relleno de HTML
# ----------------------------------------------------------------------------
SPAN_FUENTE = "<span style='font-family:\"Calibri\",sans-serif'>%s</span>"


def rellenar_tabla(html, filas_valores):
    """Rellena la tabla: una fila de datos por cuenta
    (DNI, NOMBRE, CUENTA, F. ADQ, DK), copiando el formato de la fila modelo."""
    m = re.search(r"<table\b.*?</table>", html, re.S | re.I)
    if not m:
        return html, False
    tabla = m.group(0)
    filas = list(re.finditer(r"<tr\b.*?</tr>", tabla, re.S | re.I))
    if len(filas) < 2:
        return html, False
    modelo = filas[1].group(0)
    celdas = list(re.finditer(r"(<td\b[^>]*>)(.*?)(</td>)", modelo, re.S | re.I))
    if len(celdas) < 5:
        return html, False
    generadas = []
    for valores in filas_valores:
        nueva = modelo
        for celda, valor in reversed(list(zip(celdas, valores))):
            contenido = "<p class=MsoNormal>%s</p>" % (SPAN_FUENTE % esc(valor))
            nueva = nueva[:celda.start()] + celda.group(1) + contenido + celda.group(3) + nueva[celda.end():]
        generadas.append(nueva)
    nueva_tabla = tabla[:filas[1].start()] + "".join(generadas) + tabla[filas[1].end():]
    return html[:m.start()] + nueva_tabla + html[m.end():], True


def rellenar_sentinel(html, nombre, dni):
    nuevo, n = re.subn(r"(?i)xxxx", esc("%s - DNI %s" % (nombre, dni)), html, count=1)
    return nuevo, n > 0


def rellenar_carta(html, dni, nombre):
    html, n1 = re.subn(r"(DNI:)(?:\s|&nbsp;)*(</span>)", r"\1 %s\2" % esc(dni), html, count=1)
    html, n2 = re.subn(r"(Titular de la deuda:)(?:\s|&nbsp;)*(</span>)", r"\1 %s\2" % esc(nombre),
                       html, count=1)
    return html, (n1 > 0 and n2 > 0)


def armar_correo(cfg_plantilla, entidad_clave, dni, datos):
    ruta_oft = os.path.join(CARPETA_PLANTILLAS, cfg_plantilla["archivo"])
    if not os.path.exists(ruta_oft):
        raise FileNotFoundError("No encuentro la plantilla:\n" + ruta_oft)

    outlook = win32com.client.Dispatch("Outlook.Application")
    mail = outlook.CreateItemFromTemplate(ruta_oft)

    nombre = datos[0]["nombre"]
    cuenta = "-".join(d["cuenta"] for d in datos)
    asunto = ASUNTOS[cfg_plantilla["kind"]].format(
        entidad=NOMBRE_ENTIDAD[entidad_clave], dni=dni, cuenta=cuenta, nombre=nombre,
        fecha=dt.datetime.now().strftime("%d%m%Y"))
    mail.Subject = asunto

    html = mail.HTMLBody
    kind = cfg_plantilla["kind"]
    if kind == "tabla":
        html, ok = rellenar_tabla(html, [[dni, d["nombre"], d["cuenta"], fmt_fecha(d["f_adq"]), fmt_dk(d["dk"])]
                                         for d in datos])
    elif kind == "sentinel":
        html, ok = rellenar_sentinel(html, nombre, dni)
    else:
        html, ok = rellenar_carta(html, dni, nombre)
    mail.HTMLBody = html
    mail.Display()   # lo deja abierto: adjunta evidencias y envía tú
    return ok


def datos_inhibicion(tipo, dni, contacto, motivo):
    _, columnas = TIPOS_INHIBICION[tipo]
    if ("CORREO" not in columnas or dni) and not re.fullmatch(r"[0-9]{8}", dni):
        raise ErrorDatos("Ingresa un DNI de 8 dígitos.")
    if "NÚMERO" in columnas:
        digitos = re.sub(r"[ ().-]", "", contacto)
        if not re.fullmatch(r"\+?[0-9]{7,15}", digitos):
            raise ErrorDatos("Ingresa un teléfono válido, con 7 a 15 dígitos.")
    if "CORREO" in columnas and not re.fullmatch(r"[^\s@<>]+@[^\s@<>]+\.[^\s@<>]+", contacto):
        raise ErrorDatos("Ingresa una dirección de correo válida.")
    if not motivo:
        raise ErrorDatos("Ingresa el motivo de la inhibición.")

    return {"DNI": dni, "CORREO": contacto, "NÚMERO": contacto, "MOTIVO": motivo}


def rellenar_inhibicion(html, columnas, campos):
    patron_celda = r"(<t[dh]\b[^>]*>)(.*?)(</t[dh]>)"
    for tabla in re.finditer(r"<table\b.*?</table>", html, re.S | re.I):
        filas = list(re.finditer(r"<tr\b.*?</tr>", tabla[0], re.S | re.I))
        if len(filas) != 2:
            continue
        cabecera, datos = (list(re.finditer(patron_celda, fila[0], re.S | re.I)) for fila in filas)
        titulos = tuple(unescape(re.sub(r"<[^>]+>", "", celda[2])).strip().upper()
                        for celda in cabecera)
        if titulos != columnas or len(datos) != len(columnas):
            continue

        fila_datos = filas[1][0]
        for celda, titulo in reversed(list(zip(datos, columnas))):
            parrafo = re.search(r"<p\b[^>]*>", celda[2], re.I)
            apertura = parrafo[0] if parrafo else "<p>"
            valor = esc(campos[titulo]) or "&nbsp;"
            contenido = f"{apertura}{SPAN_FUENTE % valor}</p>"
            fila_datos = fila_datos[:celda.start(2)] + contenido + fila_datos[celda.end(2):]

        fila_cabecera = filas[0][0]
        if columnas[0] == "NÚMERO":
            primera = cabecera[0]
            dni_cabecera = primera[0].replace("NÚMERO", "DNI")
            if dni_cabecera == primera[0]:
                dni_cabecera = primera[1] + '<p align="center"><b>DNI</b></p>' + primera[3]
            fila_cabecera = fila_cabecera[:primera.start()] + dni_cabecera + fila_cabecera[primera.start():]
            primera = datos[0]
            dni_datos = primera[1] + f'<p align="center">{SPAN_FUENTE % esc(campos["DNI"])}</p>' + primera[3]
            fila_datos = fila_datos[:primera.start()] + dni_datos + fila_datos[primera.start():]

        inicio, fin = tabla.span()
        nueva_tabla = (tabla[0][:filas[0].start()] + fila_cabecera
                       + tabla[0][filas[0].end():filas[1].start()] + fila_datos
                       + tabla[0][filas[1].end():])
        return html[:inicio] + nueva_tabla + html[fin:]
    raise ErrorDatos("No encontré la tabla con las columnas " + ", ".join(columnas) + " en la plantilla.")


def armar_inhibicion(tipo, campos):
    archivo, columnas = TIPOS_INHIBICION[tipo]
    ruta = os.path.join(CARPETA_PLANTILLAS, archivo)
    if not os.path.isfile(ruta):
        raise ErrorDatos(f"Coloca {archivo} en la carpeta del programa:\n{CARPETA_PLANTILLAS}")
    outlook = win32com.client.Dispatch("Outlook.Application")
    mail = outlook.CreateItemFromTemplate(ruta)
    mail.HTMLBody = rellenar_inhibicion(mail.HTMLBody, columnas, campos)
    mail.Subject = f"{mail.Subject.rstrip()} {dt.datetime.now():%d%m%y}"
    mail.Display()


# ----------------------------------------------------------------------------
# Ventana
# ----------------------------------------------------------------------------
class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Enviar plantilla de correo")
        self.resizable(False, False)
        self.cfg = cargar_config()
        pad = dict(padx=10, pady=5)

        ttk.Label(self, text="Plantilla").grid(row=0, column=0, sticky="w", **pad)
        self.cb_plantilla = ttk.Combobox(self, values=list(PLANTILLAS), state="readonly", width=34)
        self.cb_plantilla.current(0)
        self.cb_plantilla.grid(row=0, column=1, **pad)
        self.cb_plantilla.bind("<<ComboboxSelected>>", self._cambiar_plantilla)

        lbl_entidad = ttk.Label(self, text="Entidad")
        lbl_entidad.grid(row=1, column=0, sticky="w", **pad)
        self.cb_entidad = ttk.Combobox(self, values=list(TABLAS), state="readonly", width=34)
        self.cb_entidad.current(0)
        self.cb_entidad.grid(row=1, column=1, **pad)
        self.cb_entidad.bind("<<ComboboxSelected>>", self._toggle_otros)

        lbl_otros = ttk.Label(self, text="Nombre entidad (solo OTROS)")
        lbl_otros.grid(row=2, column=0, sticky="w", **pad)
        self.en_otros = ttk.Entry(self, width=37, state="disabled")
        self.en_otros.grid(row=2, column=1, **pad)

        self.lbl_dni = ttk.Label(self, text="DNI")
        self.lbl_dni.grid(row=3, column=0, sticky="w", **pad)
        self.en_dni = ttk.Entry(self, width=37)
        self.en_dni.grid(row=3, column=1, **pad)

        lbl_cuenta = ttk.Label(self, text="N.º de cuenta(s)\n(una por línea o con coma)")
        lbl_cuenta.grid(row=4, column=0, sticky="w", **pad)
        self.en_cta = tk.Text(self, width=28, height=4)
        self.en_cta.grid(row=4, column=1, **pad)
        self.campos_excel = (lbl_entidad, self.cb_entidad, lbl_otros, self.en_otros,
                             lbl_cuenta, self.en_cta)

        lbl_tipo = ttk.Label(self, text="Tipo de inhibición")
        lbl_tipo.grid(row=1, column=0, sticky="w", **pad)
        self.cb_tipo = ttk.Combobox(self, values=list(TIPOS_INHIBICION), state="readonly", width=34)
        self.cb_tipo.current(0)
        self.cb_tipo.grid(row=1, column=1, **pad)
        self.cb_tipo.bind("<<ComboboxSelected>>", self._cambiar_tipo)
        self.lbl_contacto = ttk.Label(self)
        self.lbl_contacto.grid(row=4, column=0, sticky="w", **pad)
        self.en_contacto = ttk.Entry(self, width=37)
        self.en_contacto.grid(row=4, column=1, **pad)
        lbl_motivo = ttk.Label(self, text="Motivo")
        lbl_motivo.grid(row=5, column=0, sticky="w", **pad)
        self.en_motivo = ttk.Entry(self, width=37)
        self.en_motivo.grid(row=5, column=1, **pad)
        self.campos_inhibicion = (lbl_tipo, self.cb_tipo, lbl_motivo, self.en_motivo,
                                  self.lbl_contacto, self.en_contacto)

        self.lbl = ttk.Label(self, text="", foreground="#555")
        self.lbl.grid(row=6, column=0, columnspan=2, **pad)
        self.btn = ttk.Button(self, text="Buscar datos y abrir correo", command=self.ejecutar)
        self.btn.grid(row=7, column=0, columnspan=2, pady=(5, 12))
        self._cambiar_plantilla()
        self.en_dni.focus()
        self.en_dni.bind("<Return>", lambda e: self.ejecutar())

    def _toggle_otros(self, _=None):
        self.en_otros.config(state="normal" if self.cb_entidad.get() == "OTROS" else "disabled")

    def _cambiar_plantilla(self, _=None):
        inhibicion = PLANTILLAS[self.cb_plantilla.get()]["kind"] == "inhibicion"
        mostrar, ocultar = (self.campos_inhibicion, self.campos_excel) if inhibicion else (
            self.campos_excel, self.campos_inhibicion)
        for campo in ocultar:
            campo.grid_remove()
        for campo in mostrar:
            campo.grid()
        self.lbl.config(text="")
        if inhibicion:
            self._cambiar_tipo()
            self.btn.config(text="Abrir correo en Outlook")
        else:
            self.lbl_dni.config(text="DNI")
            self.btn.config(text="Buscar datos y abrir correo")

    def _cambiar_tipo(self, _=None):
        tipo = self.cb_tipo.get()
        self.lbl.config(text="")
        self.lbl_dni.config(text="DNI (opcional)" if tipo == "Correo" else "DNI")
        self.en_contacto.delete(0, "end")
        self.en_motivo.delete(0, "end")
        if tipo == "Solo DNI":
            self.lbl_contacto.grid_remove()
            self.en_contacto.grid_remove()
        else:
            self.lbl_contacto.config(text="Correo" if tipo == "Correo" else "Teléfono")
            self.lbl_contacto.grid()
            self.en_contacto.grid()

    def _ejecutar_inhibicion(self, dni):
        tipo = self.cb_tipo.get()
        try:
            campos = datos_inhibicion(tipo, dni, self.en_contacto.get().strip(),
                                       self.en_motivo.get().strip())
            armar_inhibicion(tipo, campos)
        except ErrorDatos as e:
            messagebox.showwarning("Revisa los datos", str(e))
        except Exception as e:
            messagebox.showerror("Error al preparar el correo", str(e))
        else:
            self.lbl.config(text="Correo abierto en Outlook para revisión.")
            self.en_dni.delete(0, "end")
            self.en_contacto.delete(0, "end")
            self.en_motivo.delete(0, "end")
            self.en_dni.focus()

    def ejecutar(self):
        dni = self.en_dni.get().strip()
        plantilla = PLANTILLAS[self.cb_plantilla.get()]
        if plantilla["kind"] == "inhibicion":
            self._ejecutar_inhibicion(dni)
            return
        cuentas = list(dict.fromkeys(c for c in re.split(r"[\s,;]+", self.en_cta.get("1.0", "end")) if c))
        entidad = self.cb_entidad.get()
        if not dni or not cuentas:
            messagebox.showwarning("Faltan datos", "Ingresa el DNI y al menos un número de cuenta.")
            return
        if plantilla["solo_interbank"] and entidad != "IBK":
            if not messagebox.askyesno(
                    "Revisa destinatarios",
                    "Esta plantilla tiene destinatarios de Interbank y elegiste %s.\n¿Continuar?" % entidad):
                return
        ruta = obtener_ruta_excel(self.cfg)
        if not ruta:
            return
        hoja, tabla = TABLAS[entidad]

        self.btn.config(state="disabled")
        self.lbl.config(text="Actualizando datos del Excel, espera un momento…")
        self.update_idletasks()
        try:
            datos = consultar_excel(ruta, hoja, tabla, dni, cuentas, plantilla["tipo"],
                                    plantilla["registrar"], self.en_otros.get().strip())
            ok = armar_correo(plantilla, entidad, dni, datos)
            if not ok:
                messagebox.showwarning(
                    "Revisa el correo",
                    "El correo se abrió, pero no pude reemplazar todos los campos de la plantilla. "
                    "Revísalo antes de enviar.")
            self.lbl.config(text="Listo: %s (%d cuenta/s)" % (datos[0]["nombre"], len(datos)))
            self.en_dni.delete(0, "end")
            self.en_cta.delete("1.0", "end")
            self.en_dni.focus()
        except ErrorDatos as e:
            messagebox.showerror("Cuenta no encontrada", str(e))
            self.lbl.config(text="")
        except Exception as e:
            messagebox.showerror("Error", "%s: %s" % (type(e).__name__, e))
            self.lbl.config(text="")
        finally:
            self.btn.config(state="normal")


if __name__ == "__main__":
    App().mainloop()
