@echo off
cd /d "%~dp0"
pip install pywin32 -q
pythonw enviar_plantilla.py
if errorlevel 1 (
  python enviar_plantilla.py
  pause
)
